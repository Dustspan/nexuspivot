const express = require('express');
const path = require('path');
const multer = require('multer');
const { Readable } = require('stream');
const app = express();
const PORT = process.env.PORT || 3000;
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 50 * 1024 * 1024,
  }
});
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
let wasmModule;
try {
    wasmModule = require('./wasm_encoder_tool.js');
    console.log('✅ WASM 模块加载成功');
} catch (error) {
    console.error('❌ WASM 模块加载失败:', error);
    console.log('⚠️  在没有WASM模块的情况下运行，部分功能可能受限');
}
const textEncoder = new TextEncoder();
const textDecoder = new TextDecoder();
function processInputData(inputData, inputType, encoding) {
    if (requiresBinaryInput(encoding) && inputType === 'text') {
        return textEncoder.encode(inputData);
    }
    if (requiresStringInput(encoding) && inputType === 'file') {
        if (inputData instanceof Buffer) {
            return inputData.toString('utf-8');
        }
        return inputData;
    }
    return inputData;
}
function processOutputData(result, encoding) {
    // 对于二进制结果，直接返回 Buffer
    if (result instanceof Uint8Array) {
        return Buffer.from(result);
    }    
    // 对于字符串结果，根据编码类型决定是否编码
    if (typeof result === 'string') {
        if (requiresBinaryOutput(encoding)) {
            return Buffer.from(result, 'utf-8');
        }
        return result;
    }
    return result;
}
// API 路由 - 处理文本数据
app.post('/api/process-text', async (req, res) => {
    try {
        const { 
            encoding, 
            input, 
            key, 
            shift, 
            charset = 'utf-8' 
        } = req.body;
        console.log(`处理文本请求: ${encoding}`);
        if (!input || !encoding) {
            return res.status(400).json({ 
                success: false, 
                error: '缺少必要的输入参数' 
            });
        }
        const startTime = Date.now();
        let result;
        try {
            // 检查WASM模块是否可用
            if (!wasmModule) {
                throw new Error('WASM模块未加载，无法处理请求');
            }
            const processedInput = processInputData(input, 'text', encoding);
            result = executeWasmProcessing(encoding, processedInput, key, shift, charset);
            const output = processOutputData(result, encoding);
            const processingTime = Date.now() - startTime;
            console.log(`文本处理完成: ${encoding}, 耗时: ${processingTime}ms`);
            // 确定结果类型
            const isBinary = output instanceof Buffer;
            if (isBinary) {
                // 对于二进制数据，直接发送二进制响应
                res.set({
                    'Content-Type': 'application/octet-stream',
                    'Content-Disposition': `attachment; filename="result_${encoding}.bin"`,
                    'X-Result-Type': 'binary',
                    'X-Processing-Time': processingTime,
                    'X-Output-Size': output.length
                });
                res.send(output);
            } else {
                // 对于文本数据，发送 JSON 响应
                res.json({
                    success: true,
                    result: output,
                    resultType: 'text',
                    processingTime: processingTime,
                    outputSize: Buffer.byteLength(output, 'utf8')
                });
            }
        } catch (wasmError) {
            console.error('WASM 处理错误:', wasmError);
            res.status(500).json({ 
                success: false, 
                error: `处理失败: ${wasmError.message}` 
            });
        }
    } catch (error) {
        console.error('服务器错误:', error);
        res.status(500).json({ 
            success: false, 
            error: `服务器错误: ${error.message}` 
        });
    }
});
// API 路由 - 处理文件数据
app.post('/api/process-file', upload.single('file'), async (req, res) => {
    try {
        const { 
            encoding, 
            key, 
            shift, 
            charset = 'utf-8' 
        } = req.body;
        const file = req.file;
        console.log(`处理文件请求: ${encoding}, 文件名: ${file?.originalname}, 大小: ${file?.size} bytes`);
        if (!file || !encoding) {
            return res.status(400).json({ 
                success: false, 
                error: '缺少文件或编码类型' 
            });
        }
        const startTime = Date.now();
        let result;
        try {
            // 检查WASM模块是否可用
            if (!wasmModule) {
                throw new Error('WASM模块未加载，无法处理请求');
            }
            const processedInput = processInputData(file.buffer, 'file', encoding);
            result = executeWasmProcessing(encoding, processedInput, key, shift, charset);
            const output = processOutputData(result, encoding);            
            const processingTime = Date.now() - startTime;
            console.log(`文件处理完成: ${encoding}, 耗时: ${processingTime}ms`);
            // 确定结果类型和文件名
            const isBinary = output instanceof Buffer;
            const fileExtension = getFileExtension(encoding, isBinary);
            const filename = `result_${encoding}_${Date.now()}.${fileExtension}`;
            if (isBinary) {
                // 二进制响应
                res.set({
                    'Content-Type': 'application/octet-stream',
                    'Content-Disposition': `attachment; filename="${filename}"`,
                    'X-Result-Type': 'binary',
                    'X-Processing-Time': processingTime,
                    'X-Output-Size': output.length,
                    'X-Filename': filename
                });
                res.send(output);
            } else {
                // 文本响应
                res.set({
                    'Content-Type': 'text/plain; charset=utf-8',
                    'Content-Disposition': `attachment; filename="${filename}"`,
                    'X-Result-Type': 'text',
                    'X-Processing-Time': processingTime,
                    'X-Output-Size': Buffer.byteLength(output, 'utf8'),
                    'X-Filename': filename
                });
                res.send(output);
            }
        } catch (wasmError) {
            console.error('WASM 处理错误:', wasmError);
            res.status(500).json({ 
                success: false, 
                error: `处理失败: ${wasmError.message}` 
            });
        }
    } catch (error) {
        console.error('服务器错误:', error);
        res.status(500).json({ 
            success: false, 
            error: `服务器错误: ${error.message}` 
        });
    }
});
// 执行 WASM 处理
function executeWasmProcessing(encoding, input, key, shift, charset) {
    switch (encoding) {
        case 'base64_encode':
            return wasmModule.base64_encode(input);
        case 'base64_decode':
            const decoded = wasmModule.base64_decode(input);
            return decoded;
        case 'base64_url_encode':
            return wasmModule.base64_url_encode(input);
        case 'base64_url_decode':
            return wasmModule.base64_url_decode(input);
        case 'hex_encode':
            return wasmModule.hex_encode(input);
        case 'hex_decode':
            return wasmModule.hex_decode(input);
        case 'url_encode':
            return wasmModule.url_encode(input);
        case 'url_decode':
            return wasmModule.url_decode(input);
        case 'html_encode':
            return wasmModule.html_encode(input);
        case 'html_decode':
            return wasmModule.html_decode(input);
        case 'text_encode':
            return wasmModule.text_encode(input, charset);
        case 'text_decode':
            return wasmModule.text_decode(input, charset);
        case 'gzip_compress':
            return wasmModule.gzip_compress(input);
        case 'gzip_decompress':
            return wasmModule.gzip_decompress(input);
        case 'deflate_compress':
            return wasmModule.deflate_compress(input);
        case 'deflate_decompress':
            return wasmModule.deflate_decompress(input);
        case 'json_stringify':
            return wasmModule.json_stringify(input);
        case 'json_parse':
            return wasmModule.json_parse(input);
        case 'json_minify':
            return wasmModule.json_minify(input);
        case 'rot13_encode':
            return wasmModule.rot13_encode(input);
        case 'rot13_decode':
            return wasmModule.rot13_decode(input);
        case 'xor_cipher':
            const keyBytes = textEncoder.encode(key || '');
            return wasmModule.xor_cipher(input, keyBytes);
        case 'xor_decode':
            const keyBytesDecode = textEncoder.encode(key || '');
            return wasmModule.xor_decode(input, keyBytesDecode);
        case 'binary_to_string':
            return wasmModule.binary_to_string(input);
        case 'string_to_binary':
            return wasmModule.string_to_binary(input);
        case 'ascii_encode':
            return wasmModule.ascii_encode(input);
        case 'ascii_decode':
            return wasmModule.ascii_decode(input);
        case 'utf16_encode':
            return wasmModule.utf16_encode(input);
        case 'utf16_decode':
            return wasmModule.utf16_decode(input);
        case 'utf16le_encode':
            return wasmModule.utf16le_encode(input);
        case 'utf16le_decode':
            return wasmModule.utf16le_decode(input);
        case 'utf16be_encode':
            return wasmModule.utf16be_encode(input);
        case 'utf16be_decode':
            return wasmModule.utf16be_decode(input);
        case 'caesar_cipher_encode':
            return wasmModule.caesar_cipher_encode(input, shift || 13);
        case 'caesar_cipher_decode':
            return wasmModule.caesar_cipher_decode(input, shift || 13);
        case 'base32_encode':
            return wasmModule.base32_encode(input);
        case 'base32_decode':
            return wasmModule.base32_decode(input);
        case 'base32_hex_encode':
            return wasmModule.base32_hex_encode(input);
        case 'base32_hex_decode':
            return wasmModule.base32_hex_decode(input);
        case 'md5_hash':
            return wasmModule.md5_hash(input);
        case 'sha1_hash':
            return wasmModule.sha1_hash(input);
        case 'sha256_hash':
            return wasmModule.sha256_hash(input);
        case 'sha512_hash':
            return wasmModule.sha512_hash(input);
        case 'morse_encode':
            return wasmModule.morse_encode(input);
        case 'morse_decode':
            return wasmModule.morse_decode(input);
        case 'binary_encode':
            return wasmModule.binary_encode(input);
        case 'binary_decode':
            return wasmModule.binary_decode(input);
        default:
            throw new Error(`不支持的编码类型: ${encoding}`);
    }
}
// 检查是否需要二进制输入
function requiresBinaryInput(encoding) {
    const binaryInputEncodings = [
        'base64_encode', 'base64_url_encode', 'hex_encode', 'gzip_compress',
        'deflate_compress', 'xor_cipher', 'xor_decode', 'string_to_binary',
        'ascii_decode', 'utf16le_decode', 'utf16be_decode', 'base32_encode',
        'base32_hex_encode', 'md5_hash', 'sha1_hash', 'sha256_hash', 'sha512_hash',
        'binary_to_string'
    ];
    return binaryInputEncodings.includes(encoding);
}
// 检查是否需要字符串输入
function requiresStringInput(encoding) {
    const stringInputEncodings = [
        'base64_decode', 'base64_url_decode', 'hex_decode', 'url_encode', 
        'url_decode', 'html_encode', 'html_decode', 'json_stringify',
        'json_parse', 'json_minify', 'rot13_encode', 'rot13_decode',
        'text_encode', 'text_decode', 'morse_encode', 'morse_decode',
        'binary_encode', 'binary_decode', 'caesar_cipher_encode', 'caesar_cipher_decode'
    ];
    return stringInputEncodings.includes(encoding);
}
// 检查是否需要二进制输出
function requiresBinaryOutput(encoding) {
    const binaryOutputEncodings = [
        'base64_decode', 'base64_url_decode', 'hex_decode', 'gzip_decompress',
        'deflate_decompress', 'xor_decode', 'string_to_binary', 'ascii_encode',
        'utf16le_encode', 'utf16be_encode', 'base32_decode', 'base32_hex_decode'
    ];
    return binaryOutputEncodings.includes(encoding);
}
// 获取文件扩展名
function getFileExtension(encoding, isBinary) {
    if (encoding.includes('_hash')) return 'txt';
    if (isBinary) return 'bin';
    if (encoding.includes('json')) return 'json';
    if (encoding.includes('html')) return 'html';
    return 'txt';
}
// 获取支持的编码列表
app.get('/api/encodings', (req, res) => {
    const encodingGroups = {
        '常用编码': [
            { value: 'base64_encode', name: 'Base64 编码', action: 'encode' },
            { value: 'base64_decode', name: 'Base64 解码', action: 'decode' },
            { value: 'url_encode', name: 'URL 编码', action: 'encode' },
            { value: 'url_decode', name: 'URL 解码', action: 'decode' },
            { value: 'html_encode', name: 'HTML 编码', action: 'encode' },
            { value: 'html_decode', name: 'HTML 解码', action: 'decode' }
        ],
        '加密算法': [
            { value: 'rot13_encode', name: 'ROT13', action: 'both' },
            { value: 'caesar_cipher_encode', name: '凯撒密码', action: 'encode' },
            { value: 'caesar_cipher_decode', name: '凯撒密码', action: 'decode' },
            { value: 'xor_cipher', name: 'XOR 加密', action: 'encode' },
            { value: 'xor_decode', name: 'XOR 解密', action: 'decode' }
        ],
        '哈希算法': [
            { value: 'md5_hash', name: 'MD5', action: 'hash' },
            { value: 'sha1_hash', name: 'SHA-1', action: 'hash' },
            { value: 'sha256_hash', name: 'SHA-256', action: 'hash' },
            { value: 'sha512_hash', name: 'SHA-512', action: 'hash' }
        ],
        '高级编码': [
            { value: 'hex_encode', name: '十六进制编码', action: 'encode' },
            { value: 'hex_decode', name: '十六进制解码', action: 'decode' },
            { value: 'base32_encode', name: 'Base32 编码', action: 'encode' },
            { value: 'base32_decode', name: 'Base32 解码', action: 'decode' },
            { value: 'binary_encode', name: '二进制编码', action: 'encode' },
            { value: 'binary_decode', name: '二进制解码', action: 'decode' }
        ],
        '压缩算法': [
            { value: 'gzip_compress', name: 'Gzip 压缩', action: 'encode' },
            { value: 'gzip_decompress', name: 'Gzip 解压', action: 'decode' },
            { value: 'deflate_compress', name: 'Deflate 压缩', action: 'encode' },
            { value: 'deflate_decompress', name: 'Deflate 解压', action: 'decode' }
        ],
        '文本处理': [
            { value: 'json_stringify', name: 'JSON 格式化', action: 'encode' },
            { value: 'json_minify', name: 'JSON 压缩', action: 'encode' },
            { value: 'json_parse', name: 'JSON 解析', action: 'decode' },
            { value: 'morse_encode', name: '摩斯编码', action: 'encode' },
            { value: 'morse_decode', name: '摩斯解码', action: 'decode' }
        ]
    };
    res.json(encodingGroups);
});
// 健康检查端点
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'ok', 
        wasmLoaded: !!wasmModule,
        timestamp: new Date().toISOString(),
        message: 'NexusPivot 服务器运行正常'
    });
});
// 提供前端页面
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
// 启动服务器
app.listen(PORT, () => {
    console.log(`NexusPivot 服务器运行在 http://localhost:${PORT}`);
    console.log(`WASM 模块状态: ${wasmModule ? '已加载' : '未加载'}`);
    console.log(`文件上传已启用，最大文件大小: 50MB`);
});