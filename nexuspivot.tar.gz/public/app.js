const { createApp, ref, computed, watch, onMounted } = Vue;
createApp({
    setup() {
        // 响应式数据
        const inputMode = ref('text');
        const inputText = ref('');
        const uploadedFile = ref(null);
        const fileInput = ref(null);
        const selectedEncoding = ref('');
        const selectedCategory = ref('');
        const key = ref('');
        const shift = ref(13);
        const charset = ref('utf-8');
        const output = ref('');
        const processing = ref(false);
        const processingTime = ref(0);
        const resultType = ref('');
        const serverConnected = ref(false);
        const encodingGroups = ref({});
        const downloadUrl = ref('');
        const downloadFilename = ref('');
        const isDragOver = ref(false);
        const wrapText = ref(true);
        const responseTime = ref(0);
        const downloadFileSize = ref(0);
        const downloadFileType = ref('');
        const downloadFileExtension = ref('txt');
        const requiresKey = computed(() => selectedEncoding.value.includes('xor'));
        const requiresShift = computed(() => selectedEncoding.value.includes('caesar'));
        const requiresCharset = computed(() => selectedEncoding.value.includes('text_'));
        const isBinarySafe = computed(() => {
            const safeEncodings = ['base64', 'hex', 'base32', 'gzip', 'deflate', 'xor'];
            return safeEncodings.some(enc => selectedEncoding.value.includes(enc));
        });
        const canProcess = computed(() => {
            if (!selectedEncoding.value) return false;
            if (inputMode.value === 'text') return inputText.value.length > 0;
            if (inputMode.value === 'file') return uploadedFile.value !== null;
            return false;
        });
        const selectedEncodingName = computed(() => {
            if (!selectedEncoding.value) return '';
            for (const category in encodingGroups.value) {
                const algorithm = encodingGroups.value[category].find(a => a.value === selectedEncoding.value);
                if (algorithm) return algorithm.name;
            }
            return selectedEncoding.value;
        });
        const showPreview = computed(() => {
            if (!output.value || resultType.value !== 'text') return false;
            return output.value.length <= 1000;
        });
        const previewContent = computed(() => {
            if (!output.value) return '';
            return output.value.length > 1000 ? 
                output.value.substring(0, 1000) + '...' : 
                output.value;
        });
        // 方法
        const triggerFileInput = () => {
            fileInput.value?.click();
        };
        const handleFileUpload = (event) => {
            const file = event.target.files[0];
            if (file) {
                uploadedFile.value = file;
            }
        };
        const handleFileDrop = (event) => {
            event.preventDefault();
            const files = event.dataTransfer.files;
            if (files.length > 0) {
                uploadedFile.value = files[0];
            }
        };
        const clearFile = () => {
            uploadedFile.value = null;
            if (fileInput.value) {
                fileInput.value.value = '';
            }
        };
        const formatFileSize = (bytes) => {
            if (bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
        };
        const getFileIcon = (filename) => {
            const ext = filename.split('.').pop().toLowerCase();
            const iconMap = {
                'txt': 'fa-file-text',
                'pdf': 'fa-file-pdf',
                'doc': 'fa-file-word',
                'docx': 'fa-file-word',
                'xls': 'fa-file-excel',
                'xlsx': 'fa-file-excel',
                'jpg': 'fa-file-image',
                'jpeg': 'fa-file-image',
                'png': 'fa-file-image',
                'gif': 'fa-file-image',
                'zip': 'fa-file-archive',
                'rar': 'fa-file-archive',
                'exe': 'fa-cogs',
                'js': 'fa-file-code',
                'html': 'fa-file-code',
                'css': 'fa-file-code'
            };
            return iconMap[ext] || 'fa-file';
        };
        const getFileType = (filename) => {
            const ext = filename.split('.').pop().toLowerCase();
            const typeMap = {
                'txt': '文本文件',
                'pdf': 'PDF文档',
                'doc': 'Word文档',
                'docx': 'Word文档',
                'xls': 'Excel文档',
                'xlsx': 'Excel文档',
                'jpg': 'JPEG图像',
                'jpeg': 'JPEG图像',
                'png': 'PNG图像',
                'gif': 'GIF图像',
                'zip': '压缩文件',
                'rar': '压缩文件',
                'exe': '可执行文件',
                'js': 'JavaScript文件',
                'html': 'HTML文件',
                'css': 'CSS文件'
            };
            return typeMap[ext] || '未知类型';
        };
        const selectCategory = (category) => {
            selectedCategory.value = category;
        };
        const selectAlgorithm = (algorithm) => {
            if (isAlgorithmAvailable(algorithm)) {
                selectedEncoding.value = algorithm.value;
            }
        };
        const isAlgorithmAvailable = (algorithm) => {
            return true;
        };
        const getAlgorithmIcon = (action) => {
            const icons = {
                encode: 'fas fa-lock',
                decode: 'fas fa-lock-open',
                both: 'fas fa-sync',
                hash: 'fas fa-fingerprint'
            };
            return icons[action] || 'fas fa-code';
        };
        const getActionText = (action) => {
            const texts = {
                encode: '编码',
                decode: '解码',
                both: '编码/解码',
                hash: '哈希计算'
            };
            return texts[action] || '处理';
        };
        const clearInputText = () => {
            inputText.value = '';
        };
        const pasteFromClipboard = async () => {
            try {
                const text = await navigator.clipboard.readText();
                inputText.value = text;
                showNotification('已从剪贴板粘贴文本', 'success');
            } catch (error) {
                console.error('粘贴失败:', error);
                showNotification('无法访问剪贴板', 'error');
            }
        };
        const toggleWrap = () => {
            wrapText.value = !wrapText.value;
        };
        const newConversion = () => {
            output.value = '';
            resultType.value = '';
            processingTime.value = 0;
            showNotification('已准备好进行新转换', 'info');
        };
        // 显示通知
        const showNotification = (message, type = 'info') => {
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.innerHTML = `
                <div class="notification-content">
                    <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
                    <span>${message}</span>
                </div>
            `;
            
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#dc2626'};
                color: white;
                padding: 12px 16px;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                z-index: 1000;
                animation: slideIn 0.3s ease-out;
                max-width: 400px;
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease-in';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }, 3000);
        };
        // 处理文本数据
        const processTextData = async () => {
            const startTime = Date.now();
            try {
                const response = await fetch('/api/process-text', {
                    method: 'POST',
                    headers: { 
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        encoding: selectedEncoding.value,
                        input: inputText.value,
                        key: key.value,
                        shift: shift.value,
                        charset: charset.value
                    })
                });
                processingTime.value = Date.now() - startTime;
                if (!response.ok) {
                    const error = await response.json();
                    throw new Error(error.error || `HTTP ${response.status}`);
                }
                const result = await response.json();                
                if (result.success) {
                    output.value = result.result;
                    resultType.value = result.resultType;
                    downloadUrl.value = '';
                    downloadFileSize.value = result.outputSize || output.value.length;
                    downloadFileType.value = '文本文件';
                    downloadFileExtension.value = 'txt';
                    showNotification('文本处理完成！', 'success');
                } else {
                    throw new Error(result.error);
                }
            } catch (error) {
                console.error('处理错误:', error);
                output.value = '错误: ' + error.message;
                resultType.value = 'text';
                showNotification('处理失败: ' + error.message, 'error');
            }
        };
        // 处理文件数据
        const processFileData = async () => {
            const startTime = Date.now();
            try {
                const formData = new FormData();
                formData.append('file', uploadedFile.value);
                formData.append('encoding', selectedEncoding.value);
                formData.append('key', key.value);
                formData.append('shift', shift.value.toString());
                formData.append('charset', charset.value);
                const response = await fetch('/api/process-file', {
                    method: 'POST',
                    body: formData
                });
                processingTime.value = Date.now() - startTime;
                if (!response.ok) {
                    const error = await response.json();
                    throw new Error(error.error || `HTTP ${response.status}`);
                }
                // 获取响应头信息
                const resultTypeHeader = response.headers.get('X-Result-Type');
                const filename = response.headers.get('X-Filename') || `result_${selectedEncoding.value}.bin`;
                const outputSize = response.headers.get('X-Output-Size') || 0;
                if (resultTypeHeader === 'binary') {
                    // 处理二进制响应
                    const blob = await response.blob();
                    downloadUrl.value = URL.createObjectURL(blob);
                    downloadFilename.value = filename;
                    output.value = '[二进制数据 - 准备下载]';
                    resultType.value = 'binary';
                    downloadFileSize.value = outputSize;
                    downloadFileType.value = '二进制文件';
                    downloadFileExtension.value = 'bin';
                    showNotification('文件处理完成，准备下载', 'success');
                } else {
                    // 处理文本响应
                    const text = await response.text();
                    output.value = text;
                    resultType.value = 'text';
                    downloadUrl.value = '';
                    downloadFileSize.value = outputSize || text.length;
                    downloadFileType.value = '文本文件';
                    downloadFileExtension.value = 'txt';
                    showNotification('文件处理完成！', 'success');
                }
            } catch (error) {
                console.error('处理错误:', error);
                output.value = '错误: ' + error.message;
                resultType.value = 'text';
                showNotification('处理失败: ' + error.message, 'error');
            }
        };
        const processData = async () => {
            if (!serverConnected.value) {
                showNotification('服务器未连接，请检查服务器状态', 'error');
                return;
            }
            if (!canProcess.value) {
                showNotification('请先选择编码类型并输入数据', 'error');
                return;
            }
            processing.value = true;
            processingTime.value = 0;
            output.value = '';
            downloadUrl.value = '';
            downloadFilename.value = '';
            downloadFileSize.value = 0;
            try {
                if (inputMode.value === 'text') {
                    await processTextData();
                } else {
                    await processFileData();
                }
            } finally {
                processing.value = false;
            }
        };
        const clearAll = () => {
            inputText.value = '';
            clearFile();
            selectedEncoding.value = '';
            selectedCategory.value = '';
            key.value = '';
            shift.value = 13;
            output.value = '';
            resultType.value = '';
            downloadUrl.value = '';
            downloadFilename.value = '';
            processingTime.value = 0;
            downloadFileSize.value = 0;
        };
        const downloadResult = () => {
            if (downloadUrl.value) {
                const a = document.createElement('a');
                a.href = downloadUrl.value;
                a.download = downloadFilename.value;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                showNotification('文件下载已开始', 'success');
            } else if (output.value && resultType.value === 'text') {
                // 对于文本结果，创建 Blob 下载
                const blob = new Blob([output.value], { type: 'text/plain;charset=utf-8' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `result_${selectedEncoding.value}_${Date.now()}.txt`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                showNotification('文件下载已开始', 'success');
            }
        };
        const copyToClipboard = async () => {
            if (!output.value) return;
            try {
                await navigator.clipboard.writeText(output.value);
                showNotification('已复制到剪贴板', 'success');
            } catch (error) {
                console.error('复制失败:', error);
                showNotification('复制失败，请手动复制', 'error');
            }
        };
        const viewFullContent = () => {
            if (output.value && typeof output.value === 'string') {
                const newWindow = window.open();
                newWindow.document.write(`
                    <!DOCTYPE html>
                    <html>
                        <head>
                            <title>完整内容 - NexusPivot</title>
                            <style>
                                body { 
                                    font-family: 'Courier New', monospace; 
                                    white-space: pre-wrap; 
                                    padding: 20px;
                                    background: #0f172a;
                                    color: white;
                                    line-height: 1.5;
                                }
                                .container { max-width: 1000px; margin: 0 auto; }
                                .header { 
                                    display: flex; 
                                    justify-content: space-between; 
                                    align-items: center;
                                    margin-bottom: 20px;
                                    padding-bottom: 10px;
                                    border-bottom: 1px solid #334155;
                                }
                                .btn {
                                    background: #dc2626;
                                    color: white;
                                    border: none;
                                    padding: 8px 16px;
                                    border-radius: 4px;
                                    cursor: pointer;
                                }
                            </style>
                        </head>
                        <body>
                            <div class="container">
                                <div class="header">
                                    <h2>完整内容预览</h2>
                                    <button class="btn" onclick="window.close()">关闭</button>
                                </div>
                                <div class="content">${output.value}</div>
                            </div>
                        </body>
                    </html>
                `);
            }
        };
        const checkServerStatus = async () => {
            try {
                const startTime = Date.now();
                const response = await fetch('/api/health');
                const data = await response.json();
                responseTime.value = Date.now() - startTime;
                serverConnected.value = data.status === 'ok';
            } catch (error) {
                serverConnected.value = false;
            }
        };
        const loadEncodings = async () => {
            try {
                const response = await fetch('/api/encodings');
                encodingGroups.value = await response.json();
                const categories = Object.keys(encodingGroups.value);
                if (categories.length > 0) {
                    selectedCategory.value = categories[0];
                }
            } catch (error) {
                console.error('加载编码列表失败:', error);
            }
        };
        // 生命周期
        onMounted(async () => {
            // 添加通知样式
            if (!document.getElementById('notification-styles')) {
                const style = document.createElement('style');
                style.id = 'notification-styles';
                style.textContent = `
                    @keyframes slideIn {
                        from { transform: translateX(100%); opacity: 0; }
                        to { transform: translateX(0); opacity: 1; }
                    }
                    @keyframes slideOut {
                        from { transform: translateX(0); opacity: 1; }
                        to { transform: translateX(100%); opacity: 0; }
                    }
                `;
                document.head.appendChild(style);
            }
            await checkServerStatus();
            await loadEncodings();
            
            setInterval(checkServerStatus, 30000);
        });
        return {
            inputMode,
            inputText,
            uploadedFile,
            fileInput,
            selectedEncoding,
            selectedCategory,
            key,
            shift,
            charset,
            output,
            processing,
            processingTime,
            resultType,
            serverConnected,
            encodingGroups,
            downloadUrl,
            downloadFilename,
            isDragOver,
            wrapText,
            responseTime,
            downloadFileSize,
            downloadFileType,
            downloadFileExtension,
            selectedEncodingName,
            requiresKey,
            requiresShift,
            requiresCharset,
            isBinarySafe,
            canProcess,
            showPreview,
            previewContent,
            triggerFileInput,
            handleFileUpload,
            handleFileDrop,
            clearFile,
            formatFileSize,
            getFileIcon,
            getFileType,
            selectCategory,
            selectAlgorithm,
            isAlgorithmAvailable,
            getAlgorithmIcon,
            getActionText,
            clearInputText,
            pasteFromClipboard,
            toggleWrap,
            newConversion,
            processData,
            clearAll,
            downloadResult,
            copyToClipboard,
            viewFullContent
        };
    }
}).mount('#app');